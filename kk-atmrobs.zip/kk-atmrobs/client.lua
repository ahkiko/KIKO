local QBCore = exports['qb-core']:GetCoreObject()
local isRobbing = false
local atmCooldown = {}  -- Store cooldown timers for each ATM

-- Configuration section
local Config = {
    ATM_Cooldown_Time = 5 * 60 * 1000,  -- 5 minutes cooldown in milliseconds
    RequiredItems = {"laptop", "gatecrack"},  -- Items required to hack the ATM
}

-- Function to start ATM hacking
local function StartATMHack(entity)
    if isRobbing then
        QBCore.Functions.Notify("You're already robbing an ATM!", "error")
        return
    end

    -- Check if enough police are online
    QBCore.Functions.TriggerCallback('atmrobbery:getPoliceCount', function(policeCount)
        if policeCount < 0 then
            QBCore.Functions.Notify("Not enough police on duty to hack the ATM!", "error")
            return
        end

        -- Check required items
        local playerData = QBCore.Functions.GetPlayerData()
        local hasRequiredItems = true
        for _, requiredItem in pairs(Config.RequiredItems) do
            local hasItem = false
            for _, item in pairs(playerData.items) do
                if item.name == requiredItem then
                    hasItem = true
                    break
                end
            end
            if not hasItem then
                hasRequiredItems = false
                break
            end
        end

        if not hasRequiredItems then
            QBCore.Functions.Notify("You need both a laptop and a gatecrack to hack the ATM!", "error")
            return
        end

        isRobbing = true
        local playerPed = PlayerPedId()

        -- Play ATM animation
        RequestAnimDict("amb@prop_human_atm@male@idle_a")
        while not HasAnimDictLoaded("amb@prop_human_atm@male@idle_a") do
            Wait(100)
        end
        TaskPlayAnim(playerPed, "amb@prop_human_atm@male@idle_a", "idle_b", 8.0, -8.0, -1, 49, 0, false, false, false)

        -- Play laptop hacking animation
        RequestAnimDict("mp_prison_break")
        while not HasAnimDictLoaded("mp_prison_break") do
            Wait(100)
        end
        TaskPlayAnim(playerPed, "mp_prison_break", "hack_loop", 8.0, -8.0, -1, 49, 0, false, false, false)

        -- Hacking progress
        local success = lib.skillCheck({'easy', 'medium', 'medium'}, {'w', 'a', 's', 'd'})

        if success then
            ClearPedTasksImmediately(playerPed)
            QBCore.Functions.Notify("Hacking successful! Retrieving cash...", "success")

            QBCore.Functions.Progressbar("atm_loot", "Collecting Cash...", 7000, false, true, {
                disableMovement = true,
                disableCarMovement = true,
                disableMouse = false,
                disableCombat = true,
            }, {}, {}, {}, function()
                TriggerServerEvent("atmrobbery:giveReward")
                QBCore.Functions.Notify("You looted the ATM!", "success")
                isRobbing = false
                atmCooldown[entity] = GetGameTimer() + Config.ATM_Cooldown_Time
            end, function()
                QBCore.Functions.Notify("You left too soon!", "error")
                isRobbing = false
            end)
        else
            ClearPedTasksImmediately(playerPed)
            QBCore.Functions.Notify("Hacking failed!", "error")
            isRobbing = false
        end

        
    end)
end



-- Register event from qb-target
RegisterNetEvent("atmrobbery:startHack", function(data)
    StartATMHack(data.entity)
end)

-- Add ATMs to qb-target
CreateThread(function()
    local atmModels = {
        `prop_atm_01`,
        `prop_atm_02`,
        `prop_atm_03`,
        `prop_fleeca_atm`
    }

    for _, model in pairs(atmModels) do
        exports['qb-target']:AddTargetModel(model, {
            options = {
                {
                    type = "client",
                    event = "atmrobbery:startHack",
                    icon = "fas fa-university",
                    label = "Hack ATM",
                    canInteract = function(entity, distance, data)
                        -- Check if the ATM is not being robbed and it's not on cooldown
                        if isRobbing then
                            return false
                        end
                        -- Check if the ATM has a cooldown
                        if atmCooldown[entity] and GetGameTimer() < atmCooldown[entity] then
                            QBCore.Functions.Notify("This ATM is still on cooldown!", "error")
                            return false
                        end
                        return distance < 2.0
                    end
                }
            },
            distance = 2.0
        })
    end
end)

-- Respawn ATMs after cooldown
CreateThread(function()
    while true do
        Wait(1000)  -- Check every second

        -- Iterate through all ATMs and check if they are ready for respawn
        for entity, cooldownEndTime in pairs(atmCooldown) do
            if GetGameTimer() >= cooldownEndTime then
                -- Reset the cooldown and make ATM available again
                atmCooldown[entity] = nil
                QBCore.Functions.Notify("ATM is available again!", "success")
            end
        end
    end
end)
