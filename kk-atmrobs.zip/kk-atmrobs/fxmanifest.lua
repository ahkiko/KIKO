fx_version 'cerulean'
game 'gta5'

description 'ATM Robbery Script (QBCore, qb-target, ox_lib)'

-- Localization and Shared Initialization
shared_scripts {
    '@qb-core/shared/locale.lua',
    '@ox_lib/init.lua',

}

client_script 'client.lua'
server_script 'server.lua'

lua54 'yes'

dependencies {
    'qb-core',
    'qb-target',
    'ox_lib'
}
