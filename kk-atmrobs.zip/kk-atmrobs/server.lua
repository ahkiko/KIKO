QBCore = exports['qb-core']:GetCoreObject()

RegisterServerEvent("atmrobbery:giveReward", function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if Player then
        -- Give the player black money as a reward
        local amount = math.random(500, 1500)
        Player.Functions.AddItem("black_money", amount, false)
        TriggerClientEvent('QBCore:Notify', src, "You received $" .. amount .. " in black money", "success")

        -- Remove the required items after the hack

        Player.Functions.RemoveItem("gatecrack", 1)

        -- Notify the player that items were removed
        TriggerClientEvent('QBCore:Notify', src, "You have lost a laptop and gatecrack.", "error")
    end
end)
-- Server-side: Get the number of police officers on duty
QBCore.Functions.CreateCallback('atmrobbery:getPoliceCount', function(source, cb)
    local policeCount = 0
    for _, playerId in pairs(QBCore.Functions.GetPlayers()) do
        local Player = QBCore.Functions.GetPlayer(playerId)
        if Player and Player.PlayerData.job.name == "police" and Player.PlayerData.job.onduty then
            policeCount = policeCount + 1
        end
    end
    cb(policeCount)
end)
